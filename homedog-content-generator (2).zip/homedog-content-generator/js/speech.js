// speech.js — Voice-to-text input via Web Speech API

function initSpeech(textareaId, buttonId) {
  const textarea = document.getElementById(textareaId);
  const button = document.getElementById(buttonId);
  if (!textarea || !button) return;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    button.title = "Voice input not supported in this browser";
    button.classList.add("disabled");
    button.addEventListener("click", () => {
      showToast("Voice input isn't supported in this browser. Try Chrome or Safari.");
    });
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  let isRecording = false;
  let finalTranscript = "";

  button.addEventListener("click", () => {
    if (isRecording) {
      recognition.stop();
    } else {
      finalTranscript = textarea.value;
      try {
        recognition.start();
      } catch (e) {
        showToast("Couldn't start voice input. Please try again.");
      }
    }
  });

  recognition.onstart = () => {
    isRecording = true;
    button.classList.add("recording");
    button.setAttribute("aria-label", "Stop recording");
  };

  recognition.onresult = (event) => {
    let interimTranscript = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += (finalTranscript ? " " : "") + transcript;
      } else {
        interimTranscript += transcript;
      }
    }
    textarea.value = finalTranscript + (interimTranscript ? " " + interimTranscript : "");
    textarea.dispatchEvent(new Event("input"));
  };

  recognition.onend = () => {
    isRecording = false;
    button.classList.remove("recording");
    button.setAttribute("aria-label", "Start voice input");
  };

  recognition.onerror = (event) => {
    isRecording = false;
    button.classList.remove("recording");
    if (event.error === "not-allowed") {
      showToast("Microphone access denied. Check your browser permissions.");
    } else if (event.error !== "aborted") {
      showToast("Voice input error. Please try again.");
    }
  };
}

function showToast(message) {
  // Uses global toast if available, otherwise alert
  if (window.showAppToast) {
    window.showAppToast(message);
  } else {
    alert(message);
  }
}

export { initSpeech };
