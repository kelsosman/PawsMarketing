// storage.js — localStorage management for drafts, posts, and ratings

const STORAGE_KEYS = {
  drafts: "homedog_drafts",
  ratings: "homedog_ratings",
  settings: "homedog_settings",
};

function safeGet(key) {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : null;
  } catch {
    return null;
  }
}

function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    if (e.name === "QuotaExceededError") {
      return "quota";
    }
    return false;
  }
}

// --- Drafts ---
function getDrafts() {
  return safeGet(STORAGE_KEYS.drafts) || [];
}

function saveDraft(draft) {
  const drafts = getDrafts();
  draft.id = draft.id || `draft_${Date.now()}`;
  draft.savedAt = new Date().toISOString();
  const existing = drafts.findIndex(d => d.id === draft.id);
  if (existing >= 0) {
    drafts[existing] = draft;
  } else {
    drafts.unshift(draft);
  }
  const result = safeSet(STORAGE_KEYS.drafts, drafts);
  return result === "quota" ? "quota" : draft;
}

function deleteDraft(draftId) {
  const drafts = getDrafts().filter(d => d.id !== draftId);
  safeSet(STORAGE_KEYS.drafts, drafts);
}

function getDraftsByDate(dateStr) {
  return getDrafts().filter(d => d.postDate === dateStr);
}

function getScheduledDrafts() {
  return getDrafts().filter(d => d.postDate);
}

function getUnscheduledDrafts() {
  return getDrafts().filter(d => !d.postDate);
}

// --- Ratings ---
function getRatings() {
  return safeGet(STORAGE_KEYS.ratings) || [];
}

function saveRating(draftId, rating) {
  const ratings = getRatings();
  rating.draftId = draftId;
  rating.ratedAt = new Date().toISOString();
  const existing = ratings.findIndex(r => r.draftId === draftId);
  if (existing >= 0) {
    ratings[existing] = rating;
  } else {
    ratings.push(rating);
  }
  safeSet(STORAGE_KEYS.ratings, ratings);
}

function getRatingForDraft(draftId) {
  return getRatings().find(r => r.draftId === draftId) || null;
}

function getPerformanceStats() {
  const ratings = getRatings();
  const drafts = getDrafts();
  if (!ratings.length) return null;

  const avgRating = ratings.reduce((sum, r) => sum + r.stars, 0) / ratings.length;

  // By content type
  const byContentType = {};
  const byPlatform = {};
  const byEventType = {};
  const paidVsOrganic = { paid: [], organic: [] };

  for (const r of ratings) {
    const draft = drafts.find(d => d.id === r.draftId);
    if (!draft) continue;

    const ct = draft.formData?.contentType || "unknown";
    if (!byContentType[ct]) byContentType[ct] = [];
    byContentType[ct].push(r.stars);

    const et = draft.formData?.eventType || "general";
    if (!byEventType[et]) byEventType[et] = [];
    byEventType[et].push(r.stars);

    const platforms = draft.formData?.platforms || [];
    for (const p of platforms) {
      if (!byPlatform[p]) byPlatform[p] = [];
      byPlatform[p].push(r.stars);
    }

    if (draft.formData?.isPaid) {
      paidVsOrganic.paid.push(r.stars);
    } else {
      paidVsOrganic.organic.push(r.stars);
    }
  }

  const avg = arr => arr.length ? (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1) : "—";

  return {
    totalRated: ratings.length,
    totalPosts: drafts.length,
    avgRating: avgRating.toFixed(1),
    byContentType: Object.fromEntries(Object.entries(byContentType).map(([k, v]) => [k, avg(v)])),
    byPlatform: Object.fromEntries(Object.entries(byPlatform).map(([k, v]) => [k, avg(v)])),
    byEventType: Object.fromEntries(Object.entries(byEventType).map(([k, v]) => [k, avg(v)])),
    paidAvg: avg(paidVsOrganic.paid),
    organicAvg: avg(paidVsOrganic.organic),
    topPosts: ratings.filter(r => r.stars >= 4).sort((a, b) => b.stars - a.stars).slice(0, 5),
  };
}

// --- Export ---
function exportDraftsAsText(drafts) {
  let text = `HomeDog Content Export — ${new Date().toLocaleDateString()}\n${"=".repeat(50)}\n\n`;
  for (const draft of drafts) {
    text += `--- ${draft.formData?.contentType || "Post"} | ${draft.postDate || "Unscheduled"} ---\n`;
    if (draft.outputs) {
      for (const [platform, content] of Object.entries(draft.outputs)) {
        text += `\n[${platform.toUpperCase()}]\n`;
        if (typeof content === "string") {
          text += content + "\n";
        } else if (content.text) {
          text += content.text + "\n";
          if (content.hashtags) text += content.hashtags + "\n";
        } else if (content.title) {
          text += `Title: ${content.title}\n${content.fullDesc || content.shortDesc || ""}\n`;
        }
      }
    }
    text += "\n\n";
  }
  return text;
}

function downloadText(text, filename) {
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function getStorageUsage() {
  let total = 0;
  for (const key of Object.values(STORAGE_KEYS)) {
    const val = localStorage.getItem(key);
    if (val) total += val.length * 2; // UTF-16 = 2 bytes per char
  }
  return {
    usedBytes: total,
    usedMB: (total / (1024 * 1024)).toFixed(2),
    nearLimit: total > 4 * 1024 * 1024, // warn at 4MB of 5MB
  };
}

export {
  getDrafts, saveDraft, deleteDraft, getDraftsByDate,
  getScheduledDrafts, getUnscheduledDrafts,
  getRatings, saveRating, getRatingForDraft, getPerformanceStats,
  exportDraftsAsText, downloadText, getStorageUsage
};
